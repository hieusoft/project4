const ApiResponse = require('../Responses/ApiResponse');

class ListingController {
  constructor({ getCatalogUseCase, getListingsUseCase, getListingByIdUseCase, createListingUseCase }) {
    this.getCatalogUseCase = getCatalogUseCase;
    this.getListingsUseCase = getListingsUseCase;
    this.getListingByIdUseCase = getListingByIdUseCase;
    this.createListingUseCase = createListingUseCase;
  }

  async getListings(req, res) {
    try {
      const listings = await this.getListingsUseCase.execute(req.query);
      return ApiResponse.success(res, listings);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err, 500);
    }
  }

  async getListingById(req, res) {
    try {
      const listing = await this.getListingByIdUseCase.execute(req.params.id);
      return ApiResponse.success(res, listing);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err);
    }
  }

  async getCatalog(req, res) {
    try {
      const listings = await this.getCatalogUseCase.execute(req.query);
      return ApiResponse.success(res, listings);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err, 500);
    }
  }

  async createListing(req, res) {
    try {
      const listing = await this.createListingUseCase.execute(req.body);
      return ApiResponse.success(res, listing, 201);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err);
    }
  }
}

module.exports = ListingController;
