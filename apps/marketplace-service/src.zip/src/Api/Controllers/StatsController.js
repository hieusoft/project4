const ApiResponse = require('../Responses/ApiResponse');

class StatsController {
  constructor({ getDailyStatsUseCase }) {
    this.getDailyStatsUseCase = getDailyStatsUseCase;
  }

  async getStats(req, res) {
    try {
      const stats = await this.getDailyStatsUseCase.execute(req.query);
      return ApiResponse.success(res, stats);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err, 500);
    }
  }
}

module.exports = StatsController;
