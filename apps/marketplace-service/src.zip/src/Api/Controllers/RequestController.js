const ApiResponse = require('../Responses/ApiResponse');

class RequestController {
  constructor({ getRequestsUseCase, createRequestUseCase, approveRequestUseCase, rejectRequestUseCase, scheduleRequestUseCase, completeRequestUseCase }) {
    this.getRequestsUseCase = getRequestsUseCase;
    this.createRequestUseCase = createRequestUseCase;
    this.approveRequestUseCase = approveRequestUseCase;
    this.rejectRequestUseCase = rejectRequestUseCase;
    this.scheduleRequestUseCase = scheduleRequestUseCase;
    this.completeRequestUseCase = completeRequestUseCase;
  }

  async getRequests(req, res) {
    try {
      const requests = await this.getRequestsUseCase.execute(req.query);
      return ApiResponse.success(res, requests);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err, 500);
    }
  }

  async createRequest(req, res) {
    try {
      const request = await this.createRequestUseCase.execute(req.body);
      return ApiResponse.success(res, request, 201);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err);
    }
  }

  async approveRequest(req, res) {
    try {
      const { id } = req.params;
      const { reviewed_by } = req.body;
      const request = await this.approveRequestUseCase.execute(id, reviewed_by);
      return ApiResponse.success(res, request);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err);
    }
  }

  async rejectRequest(req, res) {
    try {
      const { id } = req.params;
      const { reviewed_by, reason } = req.body;
      const request = await this.rejectRequestUseCase.execute(id, reviewed_by, reason);
      return ApiResponse.success(res, request);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err);
    }
  }

  async scheduleRequest(req, res) {
    try {
      const { id } = req.params;
      const { reviewed_by, scheduled_at } = req.body;
      const request = await this.scheduleRequestUseCase.execute(id, reviewed_by, scheduled_at);
      return ApiResponse.success(res, request);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err);
    }
  }

  async completeRequest(req, res) {
    try {
      const { id } = req.params;
      const request = await this.completeRequestUseCase.execute(id, req.body);
      return ApiResponse.success(res, request);
    } catch (err) {
      console.error(err);
      return ApiResponse.error(res, err);
    }
  }
}

module.exports = RequestController;
