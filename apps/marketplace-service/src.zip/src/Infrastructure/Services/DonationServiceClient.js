const http = require('http');

class DonationServiceClient {
  constructor() {
    this.baseUrl = process.env.DONATION_SERVICE_URL || 'http://donation-service:3003';
  }

  verifyInventoryItem(inventoryItemId) {
    return new Promise((resolve, reject) => {
      const req = http.get(`${this.baseUrl}/api/donation/inventory/${inventoryItemId}`, (res) => {
        let data = '';

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            try {
              const parsedData = JSON.parse(data);
              resolve(parsedData.data);
            } catch (e) {
              reject(new Error('Failed to parse response from Donation Service'));
            }
          } else if (res.statusCode === 404) {
            resolve(null); // Not found
          } else {
            reject(new Error(`Donation Service returned status ${res.statusCode}`));
          }
        });
      });

      req.on('error', (err) => {
        // Log the error but maybe return a mock object in development if the service is down
        console.error('Error calling Donation Service:', err.message);
        reject(err);
      });

      req.end();
    });
  }

  updateItemStatus(inventoryItemId, status) {
    return new Promise((resolve, reject) => {
      const data = JSON.stringify({ status });
      const options = {
        hostname: new URL(this.baseUrl).hostname,
        port: new URL(this.baseUrl).port || 80,
        path: `/api/donation/inventory/${inventoryItemId}/status`,
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': data.length
        }
      };

      const req = http.request(options, (res) => {
        let resData = '';
        res.on('data', (chunk) => resData += chunk);
        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(true);
          } else {
            reject(new Error(`Donation Service returned status ${res.statusCode}`));
          }
        });
      });

      req.on('error', (err) => {
        console.error('Error updating inventory item status:', err.message);
        reject(err);
      });

      req.write(data);
      req.end();
    });
  }
}

module.exports = new DonationServiceClient();
