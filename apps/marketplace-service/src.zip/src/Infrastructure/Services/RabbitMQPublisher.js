const amqp = require('amqplib');

class RabbitMQPublisher {
  constructor() {
    this.channel = null;
  }

  async connect() {
    try {
      const url = process.env.RABBITMQ_URL || 'amqp://charity:charity@localhost:5672';
      const connection = await amqp.connect(url);
      this.channel = await connection.createChannel();
      await this.channel.assertExchange('charity.events', 'topic', { durable: true });
      console.log('Connected to RabbitMQ');
    } catch (error) {
      console.error('RabbitMQ connection error:', error);
    }
  }

  async publish(routingKey, message) {
    if (!this.channel) {
      console.error('RabbitMQ channel not initialized');
      return;
    }
    const payload = Buffer.from(JSON.stringify(message));
    this.channel.publish('charity.events', routingKey, payload, { persistent: true });
    console.log(`Event published: ${routingKey}`);
  }
}

module.exports = new RabbitMQPublisher();
