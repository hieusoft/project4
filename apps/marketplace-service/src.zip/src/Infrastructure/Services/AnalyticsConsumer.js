const amqp = require('amqplib');

class AnalyticsConsumer {
  constructor({ statsRepository }) {
    this.statsRepository = statsRepository;
    this.amqpUrl = process.env.RABBITMQ_URL || 'amqp://localhost';
  }

  async start() {
    try {
      this.connection = await amqp.connect(this.amqpUrl);
      this.channel = await this.connection.createChannel();

      const exchange = 'charity.events';
      await this.channel.assertExchange(exchange, 'topic', { durable: true });

      const queue = await this.channel.assertQueue('marketplace.analytics.queue', { durable: true });

      // Bind all events we want to track
      const routingKeys = [
        'listing.created',
        'request.completed',
        'donation.completed',
        'user.verified',
        'group.member_approved'
      ];

      for (const key of routingKeys) {
        await this.channel.bindQueue(queue.queue, exchange, key);
      }

      this.channel.consume(queue.queue, async (msg) => {
        if (msg !== null) {
          try {
            const routingKey = msg.fields.routingKey;
            const content = JSON.parse(msg.content.toString());
            
            await this.processEvent(routingKey, content);
            
            this.channel.ack(msg);
          } catch (err) {
            console.error('Analytics Consumer Error processing message:', err);
            // Optionally nack or put in dead-letter queue
            this.channel.ack(msg); 
          }
        }
      });

      console.log('AnalyticsConsumer started, waiting for messages...');
    } catch (err) {
      console.error('AnalyticsConsumer failed to start:', err.message);
    }
  }

  async processEvent(routingKey, payload) {
    const today = new Date().toISOString().split('T')[0];
    let field = null;
    let groupId = payload.group_id || null;

    switch (routingKey) {
      case 'listing.created':
        field = 'items_listed';
        break;
      case 'request.completed':
        field = 'items_delivered';
        // Distinct people helped might require a different check, simplified here:
        await this.incrementStats(today, groupId, 'people_helped');
        break;
      case 'donation.completed':
        field = 'donations_count';
        break;
      case 'user.verified':
        field = 'new_users';
        break;
      case 'group.member_approved':
        field = 'new_members';
        break;
    }

    if (field) {
      await this.incrementStats(today, groupId, field);
    }
  }

  async incrementStats(date, groupId, field) {
    // 1. Increment for the specific group (if applicable)
    if (groupId) {
      await this.statsRepository.upsert(date, groupId, field);
    }
    // 2. Increment for the whole platform (group_id = NULL)
    await this.statsRepository.upsert(date, null, field);
  }
}

module.exports = AnalyticsConsumer;
