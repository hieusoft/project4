const Listing = require('../../../Domain/Entities/Listing');

class ListingRepository {
  constructor(db) {
    this.db = db;
  }

  async findAll(filters = {}) {
    let queryText = 'SELECT * FROM listings WHERE 1=1';
    const params = [];
    
    if (filters.status) {
      params.push(filters.status);
      queryText += ` AND status = $${params.length}`;
    }
    
    if (filters.group_id) {
      params.push(filters.group_id);
      queryText += ` AND group_id = $${params.length}`;
    }
    
    queryText += ' ORDER BY created_at DESC LIMIT 50';
    
    const { rows } = await this.db.query(queryText, params);
    return rows.map(row => new Listing(row));
  }

  async find(filters = {}) {
    return this.findAll(filters);
  }

  async findById(id) {
    const { rows } = await this.db.query('SELECT * FROM listings WHERE id = $1', [id]);
    if (rows.length === 0) return null;
    return new Listing(rows[0]);
  }

  async save(listing) {
    const queryText = `
      INSERT INTO listings (
        inventory_item_id, group_id, title, description, category_id, condition, 
        quantity_total, quantity_available, province_code, district_code, created_by, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `;
    const params = [
      listing.inventory_item_id, listing.group_id, listing.title, listing.description, 
      listing.category_id, listing.condition, listing.quantity_total, 
      listing.quantity_available, listing.province_code, listing.district_code, 
      listing.created_by, listing.status
    ];
    
    const { rows } = await this.db.query(queryText, params);
    return new Listing(rows[0]);
  }
}

module.exports = ListingRepository;
