const ItemRequest = require('../../../Domain/Entities/ItemRequest');

class RequestRepository {
  constructor(db) {
    this.db = db;
  }

  async find(filters = {}) {
    let queryText = 'SELECT * FROM item_requests WHERE 1=1';
    const params = [];
    
    if (filters.group_id) {
      params.push(filters.group_id);
      queryText += ` AND group_id = $${params.length}`;
    }
    
    if (filters.listing_id) {
      params.push(filters.listing_id);
      queryText += ` AND listing_id = $${params.length}`;
    }

    if (filters.status) {
      params.push(filters.status);
      queryText += ` AND status = $${params.length}`;
    }
    
    queryText += ' ORDER BY created_at DESC LIMIT 50';
    
    const { rows } = await this.db.query(queryText, params);
    return rows.map(row => new ItemRequest(row));
  }

  async findById(id) {
    const { rows } = await this.db.query('SELECT * FROM item_requests WHERE id = $1', [id]);
    if (rows.length === 0) return null;
    return new ItemRequest(rows[0]);
  }

  async save(request) {
    const queryText = `
      INSERT INTO item_requests (
        code, listing_id, group_id, receiver_id, quantity, reason, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;
    const params = [
      request.code, request.listing_id, request.group_id, request.receiver_id, 
      request.quantity, request.reason, request.status
    ];
    
    const { rows } = await this.db.query(queryText, params);
    return new ItemRequest(rows[0]);
  }

  async update(request) {
    const queryText = `
      UPDATE item_requests 
      SET status = $1, reviewed_by = $2, reviewed_at = $3, reject_reason = $4, scheduled_at = $5, updated_at = NOW()
      WHERE id = $6
      RETURNING *
    `;
    const params = [
      request.status, request.reviewed_by, request.reviewed_at, 
      request.reject_reason, request.scheduled_at, request.id
    ];
    
    const { rows } = await this.db.query(queryText, params);
    return new ItemRequest(rows[0]);
  }

  async completeWithTransaction(request, listing, completionData) {
    const client = await this.db.getClient();
    try {
      await client.query('BEGIN');
      
      const reqQuery = `
        UPDATE item_requests 
        SET status = $1, completed_at = $2, updated_at = NOW()
        WHERE id = $3
        RETURNING *
      `;
      const { rows: reqRows } = await client.query(reqQuery, [request.status, request.completed_at, request.id]);
      const updatedRequest = new ItemRequest(reqRows[0]);
      
      const confQuery = `
        INSERT INTO delivery_confirmations (request_id, confirmed_by, qr_token, note)
        VALUES ($1, $2, $3, $4)
      `;
      await client.query(confQuery, [request.id, completionData.confirmed_by, completionData.qr_token, completionData.note]);
      
      await client.query(`
        UPDATE listings 
        SET quantity_available = $1, status = $2 
        WHERE id = $3
      `, [listing.quantity_available, listing.status, listing.id]);
      
      await client.query('COMMIT');
      
      return { request: updatedRequest };
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }
}

module.exports = RequestRepository;
