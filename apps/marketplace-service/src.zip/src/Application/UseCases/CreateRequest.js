const ItemRequest = require('../../Domain/Entities/ItemRequest');
const { NotFoundError, DomainError } = require('../Exceptions');

class CreateRequest {
  constructor({ requestRepository, listingRepository, messagePublisher }) {
    this.requestRepository = requestRepository;
    this.listingRepository = listingRepository;
    this.messagePublisher = messagePublisher;
  }

  async execute(requestData) {
    const listing = await this.listingRepository.findById(requestData.listing_id);
    if (!listing) {
      throw new NotFoundError('Listing not found');
    }

    if (!listing.isAvailable(requestData.quantity)) {
      throw new DomainError('Listing does not have enough available quantity');
    }

    const code = `REQ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const request = new ItemRequest({ ...requestData, code });
    
    const createdRequest = await this.requestRepository.save(request);
    await this.messagePublisher.publish('request.created', {
      requestId: createdRequest.id,
      groupId: createdRequest.group_id
    });
    
    return createdRequest;
  }
}

module.exports = CreateRequest;
