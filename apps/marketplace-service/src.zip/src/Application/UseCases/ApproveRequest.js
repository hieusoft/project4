const { NotFoundError } = require('../Exceptions');

class ApproveRequest {
  constructor({ requestRepository, listingRepository, messagePublisher, donationServiceClient }) {
    this.requestRepository = requestRepository;
    this.listingRepository = listingRepository;
    this.messagePublisher = messagePublisher;
    this.donationServiceClient = donationServiceClient;
  }

  async execute(requestId, reviewerId) {
    const request = await this.requestRepository.findById(requestId);
    if (!request) {
      throw new NotFoundError('Request not found');
    }

    request.approve(reviewerId);
    const updatedRequest = await this.requestRepository.update(request);

    // Sync status to DonationService
    if (this.donationServiceClient && this.listingRepository) {
      const listing = await this.listingRepository.findById(request.listing_id);
      if (listing) {
        try {
          await this.donationServiceClient.updateItemStatus(listing.inventory_item_id, 'reserved');
        } catch (err) {
          console.warn('Could not sync reserved status to DonationService (dev fallback):', err.message);
        }
      }
    }

    await this.messagePublisher.publish('request.approved', {
      requestId: updatedRequest.id,
      receiverId: updatedRequest.receiver_id,
      groupId: updatedRequest.group_id
    });
    
    return updatedRequest;
  }
}

module.exports = ApproveRequest;
