const { NotFoundError } = require('../Exceptions');

class ScheduleRequest {
  constructor({ requestRepository, messagePublisher }) {
    this.requestRepository = requestRepository;
    this.messagePublisher = messagePublisher;
  }

  async execute(requestId, reviewerId, date) {
    const request = await this.requestRepository.findById(requestId);
    if (!request) {
      throw new NotFoundError('Request not found');
    }

    request.schedule(reviewerId, date);
    const updatedRequest = await this.requestRepository.update(request);
    await this.messagePublisher.publish('request.scheduled', {
      requestId: updatedRequest.id,
      receiverId: updatedRequest.receiver_id,
      scheduledAt: updatedRequest.scheduled_at
    });
    
    return updatedRequest;
  }
}

module.exports = ScheduleRequest;
