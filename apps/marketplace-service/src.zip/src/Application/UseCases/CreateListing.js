const Listing = require('../../Domain/Entities/Listing');
const { DomainError } = require('../Exceptions');

class CreateListing {
  constructor({ listingRepository, messagePublisher, donationServiceClient }) {
    this.listingRepository = listingRepository;
    this.messagePublisher = messagePublisher;
    this.donationServiceClient = donationServiceClient;
  }

  async execute(listingData) {
    if (this.donationServiceClient) {
      try {
        const inventoryItem = await this.donationServiceClient.verifyInventoryItem(listingData.inventory_item_id);
        if (!inventoryItem || inventoryItem.status !== 'in_stock') {
          throw new DomainError('Inventory item not found or not in stock');
        }
      } catch (err) {
        if (err instanceof DomainError) throw err;
        console.warn('Could not verify inventory item, proceeding anyway (dev mode fallback):', err.message);
      }
    }

    const listing = new Listing(listingData);
    const createdListing = await this.listingRepository.save(listing);
    await this.messagePublisher.publish('listing.created', {
      listingId: createdListing.id,
      groupId: createdListing.group_id
    });
    return createdListing;
  }
}

module.exports = CreateListing;
