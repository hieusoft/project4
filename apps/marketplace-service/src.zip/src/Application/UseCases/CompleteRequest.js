const { NotFoundError } = require('../Exceptions');

class CompleteRequest {
  constructor({ requestRepository, listingRepository, messagePublisher, donationServiceClient }) {
    this.requestRepository = requestRepository;
    this.listingRepository = listingRepository;
    this.messagePublisher = messagePublisher;
    this.donationServiceClient = donationServiceClient;
  }

  async execute(requestId, completionData) {
    const request = await this.requestRepository.findById(requestId);
    if (!request) {
      throw new NotFoundError('Request not found');
    }

    request.complete();
    
    const listing = await this.listingRepository.findById(request.listing_id);
    if (listing) {
      listing.reserve(request.quantity);
    }

    const result = await this.requestRepository.completeWithTransaction(request, listing, completionData);

    // Sync status to DonationService
    if (this.donationServiceClient && listing) {
      try {
        await this.donationServiceClient.updateItemStatus(listing.inventory_item_id, 'delivered');
      } catch (err) {
        console.warn('Could not sync delivered status to DonationService (dev fallback):', err.message);
      }
    }

    // Get listing to find donorId (created_by)
    let donorId = null;
    if (this.listingRepository) {
      const listing = await this.listingRepository.findById(request.listing_id);
      if (listing) {
        donorId = listing.created_by;
      }
    }

    await this.messagePublisher.publish('request.completed', {
      requestId: result.request.id,
      receiverId: result.request.receiver_id,
      donorId: donorId
    });
    
    return result.request;
  }
}

module.exports = CompleteRequest;
