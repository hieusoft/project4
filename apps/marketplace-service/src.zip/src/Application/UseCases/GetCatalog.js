class GetCatalog {
  constructor({ listingRepository }) {
    this.listingRepository = listingRepository;
  }

  async execute(filters = {}) {
    filters.status = 'active';
    return await this.listingRepository.find(filters);
  }
}

module.exports = GetCatalog;
