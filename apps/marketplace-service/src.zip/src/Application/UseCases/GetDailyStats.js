class GetDailyStats {
  constructor({ statsRepository }) {
    this.statsRepository = statsRepository;
  }

  async execute(filters = {}) {
    return await this.statsRepository.find(filters);
  }
}

module.exports = GetDailyStats;
