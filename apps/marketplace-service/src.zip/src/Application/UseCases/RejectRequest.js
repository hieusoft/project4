const { NotFoundError } = require('../Exceptions');

class RejectRequest {
  constructor({ requestRepository, messagePublisher }) {
    this.requestRepository = requestRepository;
    this.messagePublisher = messagePublisher;
  }

  async execute(requestId, reviewerId, reason) {
    const request = await this.requestRepository.findById(requestId);
    if (!request) {
      throw new NotFoundError('Request not found');
    }

    request.reject(reviewerId, reason);
    const updatedRequest = await this.requestRepository.update(request);
    
    return updatedRequest;
  }
}

module.exports = RejectRequest;
