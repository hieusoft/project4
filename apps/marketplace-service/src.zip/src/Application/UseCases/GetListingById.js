const { NotFoundError } = require('../Exceptions');

class GetListingById {
  constructor({ listingRepository }) {
    this.listingRepository = listingRepository;
  }

  async execute(id) {
    const listing = await this.listingRepository.findById(id);
    if (!listing) {
      throw new NotFoundError('Listing not found');
    }
    return listing;
  }
}

module.exports = GetListingById;
