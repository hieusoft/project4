class GetRequests {
  constructor({ requestRepository }) {
    this.requestRepository = requestRepository;
  }

  async execute(filters = {}) {
    return await this.requestRepository.find(filters);
  }
}

module.exports = GetRequests;
