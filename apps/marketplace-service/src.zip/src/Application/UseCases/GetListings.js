class GetListings {
  constructor({ listingRepository }) {
    this.listingRepository = listingRepository;
  }

  async execute(filters = {}) {
    return await this.listingRepository.findAll(filters);
  }
}

module.exports = GetListings;
